# Building and Deploying a Data Science Project in 2 weeks (Part 2)
Learning the basics of Natural Language Processing, Flask and ML Model Deployment by building something fun!

Make sure you have the dependancies of this project installed before running code. The dependencies can all be installed using pip and include:
* Flask
* Sklearn
* CSV


You can find my medium post here which talks through this project and its different pieces.
